public partial class MasterPage_master : System.Web.UI.MasterPage
{
}
