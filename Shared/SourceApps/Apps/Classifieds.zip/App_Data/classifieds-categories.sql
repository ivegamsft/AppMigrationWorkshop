INSERT INTO Categories (ParentCategoryId, Name)
VALUES (Null, 'Antiques & Collectibles')
GO

INSERT INTO Categories (ParentCategoryId, Name)
VALUES (Null, 'Arts & Crafts')
GO

INSERT INTO Categories (ParentCategoryId, Name)
VALUES (Null, 'Auto')
GO

INSERT INTO Categories (ParentCategoryId, Name)
VALUES (Null, 'Electronics')
GO

INSERT INTO Categories (ParentCategoryId, Name)
VALUES (Null, 'Garden')
GO

INSERT INTO Categories (ParentCategoryId, Name)
VALUES (Null, 'Home')
GO

INSERT INTO Categories (ParentCategoryId, Name)
VALUES (Null, 'Music')
GO
